﻿using System;
using System.IO;
using System.Collections.Generic;

class Papirusz
{
    public List<string> Szovegek = new List<string>();

    public void Beolvas()
    {
        string file = @"C:\Users\Cámitogep\Documents\school projects\valamiclassoscucc\papirusz.txt.txt";

        using (StreamReader bemenet = new StreamReader(file))
        {
            string sor;

            while ((sor = bemenet.ReadLine()) != null)
            {
                Szovegek.Add(sor);
            }
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        Papirusz adatok = new Papirusz();

        adatok.Beolvas();

        Console.WriteLine("Mizo izesitett tejek lista:");
        System.Threading.Thread.Sleep(1000);
        Console.WriteLine();
        Console.WriteLine("Izesítés        kapható?   5/? Hol vehető");
        System.Threading.Thread.Sleep(1000);
        

        foreach (string szoveg in adatok.Szovegek)
        {
            Console.WriteLine(szoveg);
            System.Threading.Thread.Sleep(500);
        }
    }
}
